<?php

return [

   /*
    |--------------------------------------------------------------------------
    | Basecamp 3 App User-Agent
    |--------------------------------------------------------------------------
    |
    | You must enter a User-Agent header, with both the name of your app and
    | a link to your website or an email. For more details, you can visit
    | https://github.com/basecamp/bc3-api#identifying-your-application
    */

    'user-agent' => 'Tritek Careers (https://tritekconsulting.co.uk)',

];
